//
//  Protocols.swift
//  Navigation
//
//  Created by Семён Пряничников on 27.04.2022.
//

import Foundation

protocol TapLikedDelegate: AnyObject {
    func tapLikedLabel()
}
