//
//  PhotoModel.swift
//  Navigation
//
//  Created by Семён Пряничников on 18.04.2022.
//

import Foundation

struct PhotoModel {
    var image: String
}
