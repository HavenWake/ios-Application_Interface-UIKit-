//
//  Post.swift
//  Navigation
//
//  Created by Семён Пряничников on 29.03.2022.
//

import Foundation

struct Post {
    var title: String
}
